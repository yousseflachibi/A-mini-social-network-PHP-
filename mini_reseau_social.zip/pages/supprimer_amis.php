<?php

supprimer_amis();
header("Location:index.php?page=amis");

?>