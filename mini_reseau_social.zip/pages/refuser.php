<?php

refuser_invitation();
header("Location:index.php?page=invitations");

?>